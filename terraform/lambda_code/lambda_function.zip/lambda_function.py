import json


def lambda_handler(event, context):
    msg = {"status": 200}
    return msg